#!/bin/bash
./RacerPro -- -protocol owllink -owllink-input-syntax sexpr -owllink-output-syntax sexpr

