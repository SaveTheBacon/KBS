#!/bin/bash
./RacerPro -- -protocol owllink -owllink-input-syntax functional -owllink-output-syntax functional
