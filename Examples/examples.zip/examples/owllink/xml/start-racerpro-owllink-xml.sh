#!/bin/bash
./RacerPro -- -protocol owllink 
