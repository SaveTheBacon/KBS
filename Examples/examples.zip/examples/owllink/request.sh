#!/bin/sh
time curl -0 --crlf -d@$1 http://localhost:8080

