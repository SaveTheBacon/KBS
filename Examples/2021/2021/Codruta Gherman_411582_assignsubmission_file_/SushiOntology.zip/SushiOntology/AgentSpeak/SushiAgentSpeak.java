
import jason.asSyntax.*;

import jason.environment.*;

import java.util.logging.*;

import java.io.*;
import java.util.*;

public class SushiAgentSpeak extends Environment {

    List<Person> personsInvolved = new ArrayList<>();

    public class Person {
        private int id;
        private String name;
        private String location;
        private String phoneNumber;

        public Person() { }

        public Person(int id, String name, String location, String phoneNumber) {
            this.id = id;
            this.name = name;
            this.location = location;
            this.phoneNumber = phoneNumber;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getLocation() {
            return location;
        }

        public void setLocation(String location) {
            this.location = location;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

    }

    public class Customer extends Person {
        public Customer(int id, String name, String location, String phoneNumber){
            super(id, name, location, phoneNumber);
        }
    }

    public class Chef extends Person {
        public Chef(int id, String name, String location, String phoneNumber){
            super(id, name, location, phoneNumber);
        }
    }

    public class DeliveryPerson extends Person {
        public DeliveryPerson(int id, String name, String location, String phoneNumber){
            super(id, name, location, phoneNumber);
        }
    }

    private final Logger logger = Logger.getLogger("sushi.mas2j."+SushiAgentSpeak.class.getName());

    @Override

    public void init(String[] args) {

        super.init(args);

    }

    @Override
    public boolean executeAction(String agName, Structure action) {

        if (action.getFunctor().equals("orderSushi")) {
            logger.info("\n");
            logger.info("The client orders the sushi:");
            Person customer = new Customer(3059, "Zaharia Trahanache", "str. Florilor nr 5", "0727856473");
            logger.info("Customer details: " + customer.getId() + " - " + customer.getName() + " - " + customer.getLocation() + " - " + customer.getPhoneNumber() + ".");
            personsInvolved.add(customer);
            addPercept(Literal.parseLiteral("fire"));
            return true;
        }

        if (action.getFunctor().equals("prepareSushi")) {
            logger.info("\n");
            logger.info("The chef prepares the sushi:");
            Person chef = new Chef(24, "Florin Dumitrescu", "str. Bucuresti nr 65", "0732458964");
            logger.info("Chef details: " + chef.getId() + " - " + chef.getName() + " - " + chef.getLocation() + " - " + chef.getPhoneNumber() + ".");
            personsInvolved.add(chef);
            addPercept(Literal.parseLiteral("fire"));
            return true;
        }

        if (action.getFunctor().equals("deliverSushi")) {
            logger.info("\n");
            logger.info("The delivery person dispatches the sushi");
            Person deliveryPerson = new DeliveryPerson(4858, "Andrei Visoiu", "str. Ploiesti nr 90", "0745625936");
            logger.info("Delivery person details: " + deliveryPerson.getId() + " - " + deliveryPerson.getName() + " - " + deliveryPerson.getLocation() + " - " + deliveryPerson.getPhoneNumber() + ".");
            personsInvolved.add(deliveryPerson);
            addPercept(Literal.parseLiteral("fire"));
            return true;
        }

        if (action.getFunctor().equals("listPeopleInvolved")) {
            logger.info("\n");
            logger.info("The list of people who are involved:");
            for (Person p: personsInvolved)
                logger.info("The person " + p.getName() + ", located at " + p.getLocation() + " is involved in the action.");
            addPercept(Literal.parseLiteral("fire"));
            return true;
        }

        if (true) { // you may improve this condition

             informAgsEnvironmentChanged();

        }


        return true; // the action was executed with succes

    }

    /** Called before the end of MAS execution */
    @Override
    public void stop() {
        super.stop();
    }
}