// Environment code for project CoronaAgentSpeak.mas2j


import jason.asSyntax.*;

import jason.environment.*;

import java.util.logging.*;

import java.io.*; 
import java.util.*; 


public class TestEnv extends Environment {

	List<Human> infectedPeople = new ArrayList<>();
	
	public boolean okSource = false;
	public boolean okTarget = false;
	public boolean okVector = false;
	
	public class Human {
		private int id;
		private String name;
		private int age;
		private String precondition;
		private String location;
		private String outbreak;
		private String covid_positive;
		private String symptomatic;
		private String hospitalised;
	
		public Human() {
		}
	
		public Human(int id, String name, int age, String precondition, String location, String outbreak, String covid_positive, String symptomatic, String hospitalised) {
			this.id = id;
			this.name = name;
			this.age = age;
			this.precondition = precondition;
			this.location = location;
			this.outbreak = outbreak;
			this.covid_positive = covid_positive;
			this.symptomatic = symptomatic;
			this.hospitalised = hospitalised;
		}
	
		public int getId() {
			return id;
		}
	
		public void setId(int id) {
			this.id = id;
		}
	
		public String getName() {
			return name;
		}
	
		public void setName(String name) {
			this.name = name;
		}
	
		public int getAge() {
			return age;
		}
	
		public void setAge(int age) {
			this.age = age;
		}
	
		public String getPrecondition() {
			return precondition;
		}
	
		public void setPrecondition(String precondition) {
			this.precondition = precondition;
		}
	
		public String getLocation() {
			return location;
		}
	
		public void setLocation(String location) {
			this.location = location;
		}
	
		public String getOutbreak() {
			return outbreak;
		}
	
		public void setOutbreak(String outbreak) {
			this.outbreak = outbreak;
		}
	
		public String getCovid_positive() {
			return covid_positive;
		}
	
		public void setCovid_positive(String covid_positive) {
			this.covid_positive = covid_positive;
		}
	
		public String getSymptomatic() {
			return symptomatic;
		}
	
		public void setSymptomatic(String symptomatic) {
			this.symptomatic = symptomatic;
		}
	
		public String getHospitalised() {
			return hospitalised;
		}
	
		public void setHospitalised(String hospitalised) {
			this.hospitalised = hospitalised;
		}
	}

	public class Target extends Human {
		
		public Target(int id, String name, int age, String precondition, String location, String outbreak, String covid_positive, String symptomatic, String hospitalised) {
			super(id, name, age, precondition, location, outbreak, covid_positive, symptomatic, hospitalised);
		}
	}
	
	public class Vector extends Human {
		
		public Vector(int id, String name, int age, String precondition, String location, String outbreak, String covid_positive, String symptomatic, String hospitalised) {
			super(id, name, age, precondition, location, outbreak, covid_positive, symptomatic, hospitalised);
		}
	}


	
	public class Source extends Human {
	
		public Source(int id, String name, int age, String precondition, String location, String outbreak, String covid_positive, String symptomatic, String hospitalised) {
			super(id, name, age, precondition, location, outbreak, covid_positive, symptomatic, hospitalised);
		}
	}
	
	
    private Logger logger = Logger.getLogger("CoronaAgentSpeak.mas2j."+TestEnv.class.getName());



    /** Called before the MAS execution with the args informed in .mas2j */

    @Override

    public void init(String[] args) {

        super.init(args);

    }



    @Override

    public boolean executeAction(String agName, Structure action) {
		if (action.getFunctor().equals("createSource")) {
			logger.info("Creating source...");
			Human source1 = new Source(1, "Pop Vasile", 34, "Diabet Zaharat", "Bucuresti", "Suceava", "yes", "yes", "yes");
			logger.info("Source:" + source1.getId() + ", " + source1.getName()+ ", " + source1.getPrecondition()+ ", " + source1.getLocation()+ ", " + source1.getOutbreak()+ ", " +source1.getCovid_positive()+ ", " + source1.getSymptomatic()+ ", " + source1.getHospitalised());
			infectedPeople.add(source1);
			okSource = true;
			addPercept(Literal.parseLiteral("fire"));
			return true;
		}
		if (action.getFunctor().equals("createVector")) {
			logger.info("Creating vector...");
			Human vector1 = new Vector(1, "Pop Veronica", 33, "none", "Bucuresti", "Suceava", "yes", "no", "no");
			logger.info("Vector:" + vector1.getId() + ", " + vector1.getName()+ ", " + vector1.getPrecondition()+ ", " + vector1.getLocation()+ ", " + vector1.getOutbreak()+ ", " +vector1.getCovid_positive()+ ", " + vector1.getSymptomatic()+ ", " + vector1.getHospitalised());
			infectedPeople.add(vector1);
			okVector = true;
			addPercept(Literal.parseLiteral("fire"));
			return true;
		}
		if (action.getFunctor().equals("createTarget")) {
			logger.info("Creating target...");
			Human target1 = new Target(1, "Gorida Flavia", 35, "Asthma", "Bucuresti", "Bucuresti", "yes", "yes", "yes");
			logger.info("Target:" + target1.getId() + ", " + target1.getName()+ ", " + target1.getPrecondition()+ ", " + target1.getLocation()+ ", " + target1.getOutbreak()+ ", " +target1.getCovid_positive()+ ", " + target1.getSymptomatic()+ ", " + target1.getHospitalised());
			infectedPeople.add(target1);
			okTarget = true;
			addPercept(Literal.parseLiteral("fire"));
			return true;
		}
		if (action.getFunctor().equals("listinfectedpeople")) {
			logger.info("Creating list of infected people...");
			while(okSource == false && okTarget == false && okVector == false)
			{
				
			}
			for (Human h: infectedPeople){
				logger.info("Infected person: "+ h.getName());
			}
			addPercept(Literal.parseLiteral("fire"));
			return true;
		}
        if (true) { // you may improve this condition

             informAgsEnvironmentChanged();

        }

        return true; // the action was executed with success

    }



    /** Called before the end of MAS execution */

    @Override

    public void stop() {

        super.stop();

    }

}

