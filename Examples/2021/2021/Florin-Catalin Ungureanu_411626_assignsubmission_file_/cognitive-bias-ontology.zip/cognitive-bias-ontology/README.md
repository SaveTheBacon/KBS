# cognitive-bias-ontology
https://www.frontiersin.org/articles/10.3389/fpsyg.2018.01561/full
https://upload.wikimedia.org/wikipedia/commons/6/65/Cognitive_bias_codex_en.svg
https://humanhow.com/en/list-of-cognitive-biases-with-examples/
https://www.visualcapitalist.com/11-cognitive-biases-influence-politics/
https://www.minnstate.edu/System/hr/talent_management/documents/12%20Cognitive%20Biases%20Infographic%20v%204.pdf
https://www.ideastogo.com/articles-on-innovation/quiz-what-cognitive-bias-are-you
https://www.pwc.com/ca/en/services/consulting/behavioural-economics/cognitive-biases-in-action.html