// Environment code for project CognitiveBiasAgentSpeak.mas2j

import jason.asSyntax.*;
import jason.environment.*;
import java.util.logging.*;
import java.io.*; 
import java.util.*; 

public class TestEnv extends Environment {
	List<UserProfile> reachedProfiles = new ArrayList<>();
	
	public boolean authorActionDone = false;
	public boolean readerActionDone = false;
	public boolean retweeterActionDone = false;
	
	public class UserProfile {
		private int id;
		private String name;		private String postMessage;		private String gender;
		private int age;
		private String isBiasedPoster;
	
	
		public UserProfile() {
		}
	
		public UserProfile(int id, String name,String postMessage,  String gender, int age, String isBiasedPoster) {
			this.id = id;
			this.name = name;			this.postMessage = postMessage;			this.gender = gender;
			this.age = age;
			this.isBiasedPoster = isBiasedPoster;

		}
	    		public String getGender(){			return gender;		}
		public int getId() {
			return id;
		}	
		public String getName() {
			return name;
		}			public String getPostMessage(){			return postMessage;		}
		public int getAge() {
			return age;
		}
	   public String getIsBiasedPoster(){		   return isBiasedPoster;	   }
	
	}

	public class Reader extends UserProfile {
		
		public Reader(int id, String name, String postMessage,String gender,int age,String isBiasedPoster) {
			super(id, name,postMessage,gender, age, isBiasedPoster);
		}
	}
	
	public class Retweeter extends UserProfile {
		
		public Retweeter(int id, String name, String postMessage,String gender,int age,String isBiasedPoster) {
			super(id, name,postMessage,gender, age, isBiasedPoster);
		}
	}

	
	public class Author extends UserProfile {
	
		public Author(int id, String name, String postMessage,String gender,int age,String isBiasedPoster) {
			super(id, name,postMessage,gender, age, isBiasedPoster);
		}
	}
	
	
    private Logger logger = Logger.getLogger("CognitiveBiasAgentSpeak.mas2j."+TestEnv.class.getName());

    /** Called before the MAS execution with the args informed in .mas2j */
    @Override
    public void init(String[] args) {
        super.init(args);
    }

    @Override
    public boolean executeAction(String agName, Structure action) {
		if (action.getFunctor().equals("createBiasedPost")) {			
			logger.info("Creating original author");
			UserProfile author = new Author(1, "Donalt Duck","the vaccine cause infertiliy","male", 34,"yes");
			logger.info("Author:" + author.getId() + ", " + author.getName() + "," + author.getPostMessage());
			reachedProfiles.add(author);
			authorActionDone = true;
			addPercept(Literal.parseLiteral("fire"));			
			return true;
		}
		if (action.getFunctor().equals("retweetBiasedPost")) {			
			logger.info("Creating retweeter...");
			UserProfile retweeter = new Retweeter(1, "Melania Duck","female","", 33,"no");
			logger.info("Retweeter:"  + retweeter.getName());
			reachedProfiles.add(retweeter);
			retweeterActionDone = true;
			addPercept(Literal.parseLiteral("fire"));
			return true;
		}
		if (action.getFunctor().equals("readBiasedPost")) {
			logger.info("Creating reader");
			UserProfile reader = new Reader(1, "Sarah Pence","female","", 35,"yes");
			logger.info("Reader:" + reader.getId() + ", " + reader.getName());
			reachedProfiles.add(reader);
			readerActionDone = true;
			addPercept(Literal.parseLiteral("fire"));
			return true;
		}
		if (action.getFunctor().equals("reachedReaders")) {
			logger.info("The list of total users that read the fake news...");
			while(!authorActionDone  && !readerActionDone && retweeterActionDone == false)
			{
				
			}
			for (UserProfile user: reachedProfiles){
				logger.info("Reached person by the fakenews: "+ user.getName());
			}
			addPercept(Literal.parseLiteral("fire"));
			return true;
		}
        if (true) { // you may improve this condition
             informAgsEnvironmentChanged();
        }
        return true; // the action was executed with success
    }

    /** Called before the end of MAS execution */
    @Override
    public void stop() {
        super.stop();
    }
}

