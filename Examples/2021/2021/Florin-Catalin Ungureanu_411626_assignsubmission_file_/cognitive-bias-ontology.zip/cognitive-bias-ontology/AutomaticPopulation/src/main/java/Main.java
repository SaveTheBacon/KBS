import com.racersystems.jracer.RacerClient;
import com.racersystems.jracer.RacerClientException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

public class Main {


    public static void addNewTweet(RacerClient racer, String text, int index) throws RacerClientException {
        String name = "Tweet" + index;
        racer.sendRaw("(instance " + name + " Tweet)");
        racer.sendRaw("(attribute-filler " + name + " " + index + " ID)");
        racer.sendRaw("(attribute-filler " + name + " \"" + text + "\" tweetContent)");
        String data = racer.sendRaw("(DESCRIBE-INDIVIDUAL1 " + name + ")");
        System.out.println(data);
    }
    public static JSONObject parseMessages(String jsonString) throws ParseException {
        Object object = new JSONParser().parse(jsonString);
        JSONObject jsonObject = (JSONObject) object ;
        String message =   ((JSONObject)jsonObject.get("messages")).toString();
        object = new JSONParser().parse(message);
      return (JSONObject) object;
    }
    public static JSONArray parseN(String nonPersonalized) throws ParseException {
         Object object = new JSONParser().parse(nonPersonalized);
         JSONObject jsonObject  = (JSONObject)object;
         return  (JSONArray) jsonObject.get("non_personalized");
    }
    public static void main(String[] argv) throws IOException, ParseException, RacerClientException {
        String ip = "127.0.0.1";
        int port = 8088;
        RacerClient racer = new RacerClient(ip,port);
        racer.openConnection();
        String data = racer.sendRaw("(all-individuals)");
        racer.sendRaw("(define-concrete-domain-attribute ID :type integer)");
        racer.sendRaw("(define-concrete-domain-attribute tweetContent :type string)");
        System.out.println(racer.sendRaw("(all-attributes)"));
        String urlString = "https://api.whatdoestrumpthink.com/api/v1/quotes";
        URL url = new URL(urlString);
        StringBuilder result = new StringBuilder();
        URLConnection conn = url.openConnection();
        BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String line;
        while ((line = rd.readLine()) != null) {
            result.append(line);
        }
        rd.close();
        String nonPersonalized = parseMessages(result.toString()).toString();
      JSONArray arr = parseN(nonPersonalized);
      int i = 0;
      for(Object o : arr){
          addNewTweet(racer,o.toString().replace("\"",""),i);
          i++;
      }

      System.out.println(racer.sendRaw("(all-individuals"));
    }
}
