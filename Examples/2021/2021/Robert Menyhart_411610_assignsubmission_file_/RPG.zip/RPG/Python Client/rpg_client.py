from pracer.racer_client import RacerClient
import os

def main():
    racer_client = RacerClient('192.168.56.1', 8088)
    racer_client.connect()
    racer_client.full_reset()
    result = racer_client.racer_read_file_('\"D:/rpg.racer\"')
    selection = 0
    while (selection != 10):
        os.system('cls')
        print('What would you like to do?')
        print('1.Create Player')
        print('2.Create NPC')
        print('3.List players')
        print('4.List NPCs')
        print('5.Add equipment')
        print('6.List equipment')
        print('7.Add place')
        print('8.List places')
        print('9.Move player')
        print('10.Exit')
        selection = int(input())
        if (selection == 1):
            print('Choose a nickname:')
            pname = input()
            print('Choose from one of the following races:')
            result = racer_client.racer_call('concept-children Race')
            print(result.message_content[2:len(result.message_content) - 6])
            selection = input()
            result = racer_client.racer_call('instance ' + pname + ' ' + selection.title())
            result = racer_client.racer_call('related ' + name + ' PLAYER ISCHARACTER')
            
            print('Choose from one of the following classes:')
            result = racer_client.racer_call('concept-children ' + selection.title())
            print(result.message_content[2:len(result.message_content) - 6])
            selection = input()
            result = racer_client.racer_call('instance ' + pname + ' ' + selection.title())
            
            print('Set attributes (DEFAULT/CUSTOM):')
            selection = input()
            if (selection.upper() == 'DEFAULT'):
                racer_client.racer_call('attribute-filler ' + pname + ' 100 hasHp')
                racer_client.racer_call('attribute-filler ' + pname + ' 100 hasMp')
                racer_client.racer_call('attribute-filler ' + pname + ' 0 hasLvl')
                racer_client.racer_call('attribute-filler ' + pname + ' 0 hasXp')
            else:
                for attr in ['hasHp', 'hasMp', 'hasLvl', 'hasXp']:
                    print(attr[3:] + ':')
                    val = input()
                    racer_client.racer_call('attribute-filler ' + pname + ' ' + val + ' hasHp')
                    
            print('Select spawn point:')
            result = racer_client.racer_call('concept-instances SPAWN')
            print(result.message_content[2:len(result.message_content) - 6])
            spawn = input()
            racer_client.racer_call('related ' + pname + ' ' + spawn + ' isAt')
        elif (selection == 2):
            print('Choose NPC name:')
            name = input()
            
            print('Choose from one of the following races:')
            result = racer_client.racer_call('concept-children Race')
            print(result.message_content[2:len(result.message_content) - 6])
            selection = input()
            result = racer_client.racer_call('instance ' + name + ' ' + selection.title())
            result = racer_client.racer_call('related ' + name + ' NPC ISCHARACTER')
            
            print('It can sell:')
            result = racer_client.racer_call("(define-rule (?x ?y canSell) (or (and (?x Hunter) (?y HunterEquipment)) (and (?x Elf) (?x NPC isCharacter) (?y ElfEquipment)) (and (?x Dwarf) (?x NPC isCharacter) (?y DwarfEquipment)) (and (?x Orc) (?x NPC isCharacter) (?y OrcEquipment)) ))")
            result = racer_client.racer_call('run-all-rules')
            result = racer_client.racer_call('direct-predecessors CANBESOLDBY ' + name)
            print(result.message_content[2:len(result.message_content) - 6])
        elif (selection == 3):
            result = racer_client.racer_call('retrieve (?player) (?player PLAYER ISCHARACTER)')
            msg = result.message_content
            msg = msg.replace('(', '')
            msg = msg.replace(')', '')
            msg = msg.replace('?PLAYER', '')
            msg = msg.replace('"', '')
            pnames = msg.split()
            for name in pnames:
                result = racer_client.racer_call('describe-individual ' + name);
                print(result.message_content[3:len(result.message_content) - 7])
                print()
        elif (selection == 4):
            result = racer_client.racer_call('retrieve (?npc) (?npc NPC ISCHARACTER)')
            msg = result.message_content
            msg = msg.replace('(', '')
            msg = msg.replace(')', '')
            msg = msg.replace('?NPC', '')
            msg = msg.replace('"', '')
            pnames = msg.split()
            for name in pnames:
                result = racer_client.racer_call('describe-individual ' + name);
                print(result.message_content[3:len(result.message_content) - 7])
                result = racer_client.racer_call("(define-rule (?x ?y canSell) (or (and (?x Hunter) (?y HunterEquipment)) (and (?x Elf) (?x NPC isCharacter) (?y ElfEquipment)) (and (?x Dwarf) (?x NPC isCharacter) (?y DwarfEquipment)) (and (?x Orc) (?x NPC isCharacter) (?y OrcEquipment)) ))")
                result = racer_client.racer_call('run-all-rules')
                result = racer_client.racer_call('direct-predecessors CANBESOLDBY ' + name)
                print('Can sell: ' + result.message_content[2:len(result.message_content) - 6])
                print()
        elif (selection == 5):
            print('For which Race?')
            result = racer_client.racer_call('concept-children Equipment')
            print(result.message_content[2:len(result.message_content) - 6])
            race = input()
            print('For which Class?')
            result = racer_client.racer_call('concept-children ' + race)
            print(result.message_content[2:len(result.message_content) - 6])
            clss = input()
            print('Equipment name:')
            eqname = input()
            racer_client.racer_call('instance ' + eqname.upper() + ' ' + race.upper())
            racer_client.racer_call('instance ' + eqname.upper() + ' ' + clss.upper())
            print('Equipment type? (Weapon/Armor)')
            etype = input()
            racer_client.racer_call('related ' + eqname.upper() + ' ' + etype.upper() + ' ISEQUIPMENT')
            if (etype.upper() == 'WEAPON'):
                print('Damage=')
                dmg = input()
                racer_client.racer_call('attribute-filler ' + eqname.upper() + ' ' + dmg + ' hasDmg')
            else:
            #(attribute-filler P1 100 hasHp)
                print('Armor=')
                arm = input()
                racer_client.racer_call('attribute-filler ' + eqname.upper() + ' ' + arm + ' hasArmor')
        elif (selection == 6):
            result = racer_client.racer_call('retrieve (?eq) (?eq Equipment)')
            msg = result.message_content
            msg = msg.replace('(', '')
            msg = msg.replace(')', '')
            msg = msg.replace('?EQ', '')
            msg = msg.replace('"', '')
            pnames = msg.split()
            for name in pnames:
                result = racer_client.racer_call('describe-individual ' + name);
                print(result.message_content[3:len(result.message_content) - 7])
                print()
        elif (selection == 7):
            print('Is it a spawnpoint or a city location?')
            result = racer_client.racer_call('concept-children PlaceOfInterest')
            print(result.message_content[2:len(result.message_content) - 6])
            loc = input()
            print('Name of the new place:')
            name = input()
            racer_client.racer_call('instance ' + name.upper() + ' ' + loc.upper())
        elif (selection == 8):
            result = racer_client.racer_call('retrieve (?poi) (?poi PlaceOfInterest)')
            msg = result.message_content
            msg = msg.replace('(', '')
            msg = msg.replace(')', '')
            msg = msg.replace('?POI', '')
            msg = msg.replace('"', '')
            pnames = msg.split()
            for name in pnames:
                result = racer_client.racer_call('describe-individual ' + name);
                print(result.message_content[3:len(result.message_content) - 7])
                print()
        elif (selection == 9):
            print('Player:')
            pname = input()
            print('Move to:')
            loc = input()
            racer_client.racer_call('related ' + pname + ' ' + loc + ' VISITED');
        input()
    racer_client.disconnect()
        
if __name__ == '__main__':
    main()