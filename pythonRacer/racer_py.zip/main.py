from pracer.racer_client import RacerClient


def main():
    racer_client = RacerClient('10.0.75.1', 8088)
    racer_client.connect()
    racer_client.full_reset()
    result = racer_client.racer_read_file_('\"D:/family.racer\"')
    print(result.value)
    result = racer_client.all_atomic_concepts_()
    print('CODE: ' + result.message_code)
    print('TYPE: ' + result.message_type)
    print('CONTENT: ' + result.message_content)
    racer_client.disconnect()


if __name__ == '__main__':
    main()
